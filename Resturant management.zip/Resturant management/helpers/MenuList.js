
import Pepperoni from "C:/Users/Oshini/OneDrive/Desktop/react-resturant/resturant/src/images/pepperoni.jpg";
import Margherita from "C:/Users/Oshini/OneDrive/Desktop/react-resturant/resturant/src/images/margherita.jpg";
import PedroTechSpecial from "C:/Users/Oshini/OneDrive/Desktop/react-resturant/resturant/src/images/pedrotechspecial.jpg";
import Vegan from "C:/Users/Oshini/OneDrive/Desktop/react-resturant/resturant/src/images/vegan.jpg";
import Pineapple from "C:/Users/Oshini/OneDrive/Desktop/react-resturant/resturant/src/images/pineapple.jpg";
import Expensive from "C:/Users/Oshini/OneDrive/Desktop/react-resturant/resturant/src/images/expensive.jpg";



export const MenuList = [
  {
    name: "Spicy Pizza",
    image:Pepperoni,
    price: 1500.00,
  },
  {
    name: "Pepperoni Pizza",
    image: Margherita,
    price: 1300.00,
   
  },
  {
    name: "Chicken Special Pizza",
    image: PedroTechSpecial,
    price: 1000.00,
   
  },
  {
    name: "cheese Pizza",
    image: Vegan,
    price: 800.00,
    
  },
  {
    name: "Vegitable Pizza",
    image: Pineapple,
    price: 1600.00,
    
  },
  {
    name: "Expicy Pizza",
    image: Expensive,
    price: 2000.00,
    
  },
];